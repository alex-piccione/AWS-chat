

def error(error_reason):
    return {
        "statusCode": 500,
        "statusReason": error_reason
    }

