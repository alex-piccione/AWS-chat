

def error(error_reason):
    return {
        "statusCode": 500,
        "statusReason": error_reason
    }


def test_2():
    return 2